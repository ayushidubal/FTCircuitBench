# hhl_4q - GS Pipeline Summary
**Parameter:** 3

## General Circuit Info

| Metric | Value |
|---|---|
| Qubits | 4 |
| Total Gates | 2034 |
| Depth | 1350 |
| Fidelity (vs Original) | N/A |
| Fidelity Method | Skipped |

## Clifford+T Circuit Summary

| Metric | Value |
|---|---|
| Total T-family gates | 710 |
| T gates | 707 |
| Tdg gates | 3 |
| Clifford gates | 1324 |
| Two-qubit gates | 22 |
| Circuit depth | 1350 |

## Clifford+T Interaction Graph Statistics

| Metric | Value |
|---|---|
| Number of nodes | 4 |
| Number of edges | 5 |
| Graph density | 3.6667 |
| Is connected | True |
| Connected components | 1 |
| Average degree | 2.50 |
| Std dev degree | 0.50 |
| Min degree | 2 |
| Max degree | 3 |
| Clustering coefficient | 0.8333 |
| Avg shortest path length | 1.17 |
| Diameter | 2 |
| Modularity | 0.0000 |
| Number of communities | 1 |
| Avg community size | 4.00 |
| Std community size | 0.00 |
| Min community size | 4 |
| Max community size | 4 |

## PBC Circuit Optimization Summary

| Metric | Value Pre Opt | Value Post Opt | % Reduction |
|---|---|---|---|
| Rotation Operators | N/A | N/A | 0.00% |
| Rotation Layers | N/A | N/A | 0.00% |
| Avg Rotations per Layer | N/A | N/A | 0.00% |
| Measurement Operators | N/A | N/A | 0.00% |
|  |  |  |  |
| Avg Operator Pauli Weight | N/A | N/A | 0.00% |
| Std Operator Pauli Weight | N/A | N/A | 0.00% |
| Max Operator Pauli Weight | N/A | N/A | 0.00% |
|  |  |  |  |
| Avg Qubit Interaction Degree | N/A | N/A | 0.00% |
| Std Qubit Interaction Degree | N/A | N/A | 0.00% |
| Max Qubit Interaction Degree | N/A | N/A | 0.00% |

## Pipeline Timings

| Stage | Time |
|---|---|
| Clifford+T Transpilation | 0.111s |
| PBC Conversion (Total) | 0.000s |


---

# hhl_4q - GS Pipeline Summary
**Parameter:** 10

## General Circuit Info

| Metric | Value |
|---|---|
| Qubits | 4 |
| Total Gates | 6504 |
| Depth | 4163 |
| Fidelity (vs Original) | N/A |
| Fidelity Method | Skipped |

## Clifford+T Circuit Summary

| Metric | Value |
|---|---|
| Total T-family gates | 2490 |
| T gates | 2487 |
| Tdg gates | 3 |
| Clifford gates | 4014 |
| Two-qubit gates | 22 |
| Circuit depth | 4163 |

## Clifford+T Interaction Graph Statistics

| Metric | Value |
|---|---|
| Number of nodes | 4 |
| Number of edges | 5 |
| Graph density | 3.6667 |
| Is connected | True |
| Connected components | 1 |
| Average degree | 2.50 |
| Std dev degree | 0.50 |
| Min degree | 2 |
| Max degree | 3 |
| Clustering coefficient | 0.8333 |
| Avg shortest path length | 1.17 |
| Diameter | 2 |
| Modularity | 0.0000 |
| Number of communities | 1 |
| Avg community size | 4.00 |
| Std community size | 0.00 |
| Min community size | 4 |
| Max community size | 4 |

## PBC Circuit Optimization Summary

| Metric | Value Pre Opt | Value Post Opt | % Reduction |
|---|---|---|---|
| Rotation Operators | N/A | N/A | 0.00% |
| Rotation Layers | N/A | N/A | 0.00% |
| Avg Rotations per Layer | N/A | N/A | 0.00% |
| Measurement Operators | N/A | N/A | 0.00% |
|  |  |  |  |
| Avg Operator Pauli Weight | N/A | N/A | 0.00% |
| Std Operator Pauli Weight | N/A | N/A | 0.00% |
| Max Operator Pauli Weight | N/A | N/A | 0.00% |
|  |  |  |  |
| Avg Qubit Interaction Degree | N/A | N/A | 0.00% |
| Std Qubit Interaction Degree | N/A | N/A | 0.00% |
| Max Qubit Interaction Degree | N/A | N/A | 0.00% |

## Pipeline Timings

| Stage | Time |
|---|---|
| Clifford+T Transpilation | 0.290s |
| PBC Conversion (Total) | 0.000s |


---

