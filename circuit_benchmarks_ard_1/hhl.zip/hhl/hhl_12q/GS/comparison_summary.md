# hhl_12q - GS Pipeline Summary
**Parameter:** 3

## General Circuit Info

| Metric | Value |
|---|---|
| Qubits | 12 |
| Total Gates | 191813 |
| Depth | 132492 |
| Fidelity (vs Original) | N/A |
| Fidelity Method | Skipped |

## Clifford+T Circuit Summary

| Metric | Value |
|---|---|
| Total T-family gates | 67458 |
| T gates | 66429 |
| Tdg gates | 1029 |
| Clifford gates | 124355 |
| Two-qubit gates | 3324 |
| Circuit depth | 132492 |

## Clifford+T Interaction Graph Statistics

| Metric | Value |
|---|---|
| Number of nodes | 12 |
| Number of edges | 63 |
| Graph density | 50.3636 |
| Is connected | True |
| Connected components | 1 |
| Average degree | 10.50 |
| Std dev degree | 0.87 |
| Min degree | 8 |
| Max degree | 11 |
| Clustering coefficient | 0.9636 |
| Avg shortest path length | 1.05 |
| Diameter | 2 |
| Modularity | 0.0000 |
| Number of communities | 1 |
| Avg community size | 12.00 |
| Std community size | 0.00 |
| Min community size | 12 |
| Max community size | 12 |

## PBC Circuit Optimization Summary

| Metric | Value Pre Opt | Value Post Opt | % Reduction |
|---|---|---|---|
| Rotation Operators | N/A | N/A | 0.00% |
| Rotation Layers | N/A | N/A | 0.00% |
| Avg Rotations per Layer | N/A | N/A | 0.00% |
| Measurement Operators | N/A | N/A | 0.00% |
|  |  |  |  |
| Avg Operator Pauli Weight | N/A | N/A | 0.00% |
| Std Operator Pauli Weight | N/A | N/A | 0.00% |
| Max Operator Pauli Weight | N/A | N/A | 0.00% |
|  |  |  |  |
| Avg Qubit Interaction Degree | N/A | N/A | 0.00% |
| Std Qubit Interaction Degree | N/A | N/A | 0.00% |
| Max Qubit Interaction Degree | N/A | N/A | 0.00% |

## Pipeline Timings

| Stage | Time |
|---|---|
| Clifford+T Transpilation | 10.93s |
| PBC Conversion (Total) | 0.000s |


---

# hhl_12q - GS Pipeline Summary
**Parameter:** 10

## General Circuit Info

| Metric | Value |
|---|---|
| Qubits | 12 |
| Total Gates | 581243 |
| Depth | 399634 |
| Fidelity (vs Original) | N/A |
| Fidelity Method | Skipped |

## Clifford+T Circuit Summary

| Metric | Value |
|---|---|
| Total T-family gates | 223556 |
| T gates | 222526 |
| Tdg gates | 1030 |
| Clifford gates | 357687 |
| Two-qubit gates | 3324 |
| Circuit depth | 399634 |

## Clifford+T Interaction Graph Statistics

| Metric | Value |
|---|---|
| Number of nodes | 12 |
| Number of edges | 63 |
| Graph density | 50.3636 |
| Is connected | True |
| Connected components | 1 |
| Average degree | 10.50 |
| Std dev degree | 0.87 |
| Min degree | 8 |
| Max degree | 11 |
| Clustering coefficient | 0.9636 |
| Avg shortest path length | 1.05 |
| Diameter | 2 |
| Modularity | 0.0000 |
| Number of communities | 1 |
| Avg community size | 12.00 |
| Std community size | 0.00 |
| Min community size | 12 |
| Max community size | 12 |

## PBC Circuit Optimization Summary

| Metric | Value Pre Opt | Value Post Opt | % Reduction |
|---|---|---|---|
| Rotation Operators | N/A | N/A | 0.00% |
| Rotation Layers | N/A | N/A | 0.00% |
| Avg Rotations per Layer | N/A | N/A | 0.00% |
| Measurement Operators | N/A | N/A | 0.00% |
|  |  |  |  |
| Avg Operator Pauli Weight | N/A | N/A | 0.00% |
| Std Operator Pauli Weight | N/A | N/A | 0.00% |
| Max Operator Pauli Weight | N/A | N/A | 0.00% |
|  |  |  |  |
| Avg Qubit Interaction Degree | N/A | N/A | 0.00% |
| Std Qubit Interaction Degree | N/A | N/A | 0.00% |
| Max Qubit Interaction Degree | N/A | N/A | 0.00% |

## Pipeline Timings

| Stage | Time |
|---|---|
| Clifford+T Transpilation | 28.29s |
| PBC Conversion (Total) | 0.000s |


---

