# hhl_21q - GS Pipeline Summary
**Parameter:** 3

## General Circuit Info

| Metric | Value |
|---|---|
| Qubits | 21 |
| Total Gates | 1900444 |
| Depth | 1344987 |
| Fidelity (vs Original) | N/A |
| Fidelity Method | Skipped |

## Clifford+T Circuit Summary

| Metric | Value |
|---|---|
| Total T-family gates | 674792 |
| T gates | 665099 |
| Tdg gates | 9693 |
| Clifford gates | 1225652 |
| Two-qubit gates | 33083 |
| Circuit depth | 1344987 |

## Clifford+T Interaction Graph Statistics

| Metric | Value |
|---|---|
| Number of nodes | 21 |
| Number of edges | 206 |
| Graph density | 157.5381 |
| Is connected | True |
| Connected components | 1 |
| Average degree | 19.62 |
| Std dev degree | 0.90 |
| Min degree | 16 |
| Max degree | 20 |
| Clustering coefficient | 0.9840 |
| Avg shortest path length | 1.02 |
| Diameter | 2 |
| Modularity | 0.0000 |
| Number of communities | 1 |
| Avg community size | 21.00 |
| Std community size | 0.00 |
| Min community size | 21 |
| Max community size | 21 |

## PBC Circuit Optimization Summary

| Metric | Value Pre Opt | Value Post Opt | % Reduction |
|---|---|---|---|
| Rotation Operators | N/A | N/A | 0.00% |
| Rotation Layers | N/A | N/A | 0.00% |
| Avg Rotations per Layer | N/A | N/A | 0.00% |
| Measurement Operators | N/A | N/A | 0.00% |
|  |  |  |  |
| Avg Operator Pauli Weight | N/A | N/A | 0.00% |
| Std Operator Pauli Weight | N/A | N/A | 0.00% |
| Max Operator Pauli Weight | N/A | N/A | 0.00% |
|  |  |  |  |
| Avg Qubit Interaction Degree | N/A | N/A | 0.00% |
| Std Qubit Interaction Degree | N/A | N/A | 0.00% |
| Max Qubit Interaction Degree | N/A | N/A | 0.00% |

## Pipeline Timings

| Stage | Time |
|---|---|
| Clifford+T Transpilation | 59.36s |
| PBC Conversion (Total) | 0.000s |


---

# hhl_21q - GS Pipeline Summary
**Parameter:** 10

## General Circuit Info

| Metric | Value |
|---|---|
| Qubits | 21 |
| Total Gates | 5858474 |
| Depth | 4083732 |
| Fidelity (vs Original) | N/A |
| Fidelity Method | Skipped |

## Clifford+T Circuit Summary

| Metric | Value |
|---|---|
| Total T-family gates | 2255586 |
| T gates | 2245893 |
| Tdg gates | 9693 |
| Clifford gates | 3602888 |
| Two-qubit gates | 33083 |
| Circuit depth | 4083732 |

## Clifford+T Interaction Graph Statistics

| Metric | Value |
|---|---|
| Number of nodes | 21 |
| Number of edges | 206 |
| Graph density | 157.5381 |
| Is connected | True |
| Connected components | 1 |
| Average degree | 19.62 |
| Std dev degree | 0.90 |
| Min degree | 16 |
| Max degree | 20 |
| Clustering coefficient | 0.9840 |
| Avg shortest path length | 1.02 |
| Diameter | 2 |
| Modularity | 0.0000 |
| Number of communities | 1 |
| Avg community size | 21.00 |
| Std community size | 0.00 |
| Min community size | 21 |
| Max community size | 21 |

## PBC Circuit Optimization Summary

| Metric | Value Pre Opt | Value Post Opt | % Reduction |
|---|---|---|---|
| Rotation Operators | N/A | N/A | 0.00% |
| Rotation Layers | N/A | N/A | 0.00% |
| Avg Rotations per Layer | N/A | N/A | 0.00% |
| Measurement Operators | N/A | N/A | 0.00% |
|  |  |  |  |
| Avg Operator Pauli Weight | N/A | N/A | 0.00% |
| Std Operator Pauli Weight | N/A | N/A | 0.00% |
| Max Operator Pauli Weight | N/A | N/A | 0.00% |
|  |  |  |  |
| Avg Qubit Interaction Degree | N/A | N/A | 0.00% |
| Std Qubit Interaction Degree | N/A | N/A | 0.00% |
| Max Qubit Interaction Degree | N/A | N/A | 0.00% |

## Pipeline Timings

| Stage | Time |
|---|---|
| Clifford+T Transpilation | 2.3m |
| PBC Conversion (Total) | 0.000s |


---

