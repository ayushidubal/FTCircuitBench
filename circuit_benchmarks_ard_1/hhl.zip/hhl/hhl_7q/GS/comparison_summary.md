# hhl_7q - GS Pipeline Summary
**Parameter:** 3

## General Circuit Info

| Metric | Value |
|---|---|
| Qubits | 7 |
| Total Gates | 23546 |
| Depth | 16240 |
| Fidelity (vs Original) | N/A |
| Fidelity Method | Skipped |

## Clifford+T Circuit Summary

| Metric | Value |
|---|---|
| Total T-family gates | 8296 |
| T gates | 8190 |
| Tdg gates | 106 |
| Clifford gates | 15250 |
| Two-qubit gates | 317 |
| Circuit depth | 16240 |

## Clifford+T Interaction Graph Statistics

| Metric | Value |
|---|---|
| Number of nodes | 7 |
| Number of edges | 19 |
| Graph density | 15.0952 |
| Is connected | True |
| Connected components | 1 |
| Average degree | 5.43 |
| Std dev degree | 0.73 |
| Min degree | 4 |
| Max degree | 6 |
| Clustering coefficient | 0.9238 |
| Avg shortest path length | 1.10 |
| Diameter | 2 |
| Modularity | 0.0000 |
| Number of communities | 1 |
| Avg community size | 7.00 |
| Std community size | 0.00 |
| Min community size | 7 |
| Max community size | 7 |

## PBC Circuit Optimization Summary

| Metric | Value Pre Opt | Value Post Opt | % Reduction |
|---|---|---|---|
| Rotation Operators | N/A | N/A | 0.00% |
| Rotation Layers | N/A | N/A | 0.00% |
| Avg Rotations per Layer | N/A | N/A | 0.00% |
| Measurement Operators | N/A | N/A | 0.00% |
|  |  |  |  |
| Avg Operator Pauli Weight | N/A | N/A | 0.00% |
| Std Operator Pauli Weight | N/A | N/A | 0.00% |
| Max Operator Pauli Weight | N/A | N/A | 0.00% |
|  |  |  |  |
| Avg Qubit Interaction Degree | N/A | N/A | 0.00% |
| Std Qubit Interaction Degree | N/A | N/A | 0.00% |
| Max Qubit Interaction Degree | N/A | N/A | 0.00% |

## Pipeline Timings

| Stage | Time |
|---|---|
| Clifford+T Transpilation | 0.890s |
| PBC Conversion (Total) | 0.000s |


---

# hhl_7q - GS Pipeline Summary
**Parameter:** 10

## General Circuit Info

| Metric | Value |
|---|---|
| Qubits | 7 |
| Total Gates | 72993 |
| Depth | 49643 |
| Fidelity (vs Original) | N/A |
| Fidelity Method | Skipped |

## Clifford+T Circuit Summary

| Metric | Value |
|---|---|
| Total T-family gates | 28112 |
| T gates | 28006 |
| Tdg gates | 106 |
| Clifford gates | 44881 |
| Two-qubit gates | 317 |
| Circuit depth | 49643 |

## Clifford+T Interaction Graph Statistics

| Metric | Value |
|---|---|
| Number of nodes | 7 |
| Number of edges | 19 |
| Graph density | 15.0952 |
| Is connected | True |
| Connected components | 1 |
| Average degree | 5.43 |
| Std dev degree | 0.73 |
| Min degree | 4 |
| Max degree | 6 |
| Clustering coefficient | 0.9238 |
| Avg shortest path length | 1.10 |
| Diameter | 2 |
| Modularity | 0.0000 |
| Number of communities | 1 |
| Avg community size | 7.00 |
| Std community size | 0.00 |
| Min community size | 7 |
| Max community size | 7 |

## PBC Circuit Optimization Summary

| Metric | Value Pre Opt | Value Post Opt | % Reduction |
|---|---|---|---|
| Rotation Operators | N/A | N/A | 0.00% |
| Rotation Layers | N/A | N/A | 0.00% |
| Avg Rotations per Layer | N/A | N/A | 0.00% |
| Measurement Operators | N/A | N/A | 0.00% |
|  |  |  |  |
| Avg Operator Pauli Weight | N/A | N/A | 0.00% |
| Std Operator Pauli Weight | N/A | N/A | 0.00% |
| Max Operator Pauli Weight | N/A | N/A | 0.00% |
|  |  |  |  |
| Avg Qubit Interaction Degree | N/A | N/A | 0.00% |
| Std Qubit Interaction Degree | N/A | N/A | 0.00% |
| Max Qubit Interaction Degree | N/A | N/A | 0.00% |

## Pipeline Timings

| Stage | Time |
|---|---|
| Clifford+T Transpilation | 2.20s |
| PBC Conversion (Total) | 0.000s |


---

