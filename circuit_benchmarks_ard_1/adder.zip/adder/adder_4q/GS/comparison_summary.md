# adder_4q - GS Pipeline Summary
**Parameter:** 3

## General Circuit Info

| Metric | Value |
|---|---|
| Qubits | 4 |
| Total Gates | 29 |
| Depth | 13 |
| Fidelity (vs Original) | N/A |
| Fidelity Method | Skipped |

## Clifford+T Circuit Summary

| Metric | Value |
|---|---|
| Total T-family gates | 8 |
| T gates | 4 |
| Tdg gates | 4 |
| Clifford gates | 21 |
| Two-qubit gates | 10 |
| Circuit depth | 13 |

## Clifford+T Interaction Graph Statistics

| Metric | Value |
|---|---|
| Number of nodes | 4 |
| Number of edges | 4 |
| Graph density | 1.6667 |
| Is connected | True |
| Connected components | 1 |
| Average degree | 2.00 |
| Std dev degree | 0.00 |
| Min degree | 2 |
| Max degree | 2 |
| Clustering coefficient | 0.0000 |
| Avg shortest path length | 1.33 |
| Diameter | 2 |
| Modularity | 0.1950 |
| Number of communities | 2 |
| Avg community size | 2.00 |
| Std community size | 0.00 |
| Min community size | 2 |
| Max community size | 2 |

## PBC Circuit Optimization Summary

| Metric | Value Pre Opt | Value Post Opt | % Reduction |
|---|---|---|---|
| Rotation Operators | N/A | N/A | 0.00% |
| Rotation Layers | N/A | N/A | 0.00% |
| Avg Rotations per Layer | N/A | N/A | 0.00% |
| Measurement Operators | N/A | N/A | 0.00% |
|  |  |  |  |
| Avg Operator Pauli Weight | N/A | N/A | 0.00% |
| Std Operator Pauli Weight | N/A | N/A | 0.00% |
| Max Operator Pauli Weight | N/A | N/A | 0.00% |
|  |  |  |  |
| Avg Qubit Interaction Degree | N/A | N/A | 0.00% |
| Std Qubit Interaction Degree | N/A | N/A | 0.00% |
| Max Qubit Interaction Degree | N/A | N/A | 0.00% |

## Pipeline Timings

| Stage | Time |
|---|---|
| Clifford+T Transpilation | 0.084s |
| PBC Conversion (Total) | 0.000s |


---

# adder_4q - GS Pipeline Summary
**Parameter:** 10

## General Circuit Info

| Metric | Value |
|---|---|
| Qubits | 4 |
| Total Gates | 29 |
| Depth | 13 |
| Fidelity (vs Original) | N/A |
| Fidelity Method | Skipped |

## Clifford+T Circuit Summary

| Metric | Value |
|---|---|
| Total T-family gates | 8 |
| T gates | 4 |
| Tdg gates | 4 |
| Clifford gates | 21 |
| Two-qubit gates | 10 |
| Circuit depth | 13 |

## Clifford+T Interaction Graph Statistics

| Metric | Value |
|---|---|
| Number of nodes | 4 |
| Number of edges | 4 |
| Graph density | 1.6667 |
| Is connected | True |
| Connected components | 1 |
| Average degree | 2.00 |
| Std dev degree | 0.00 |
| Min degree | 2 |
| Max degree | 2 |
| Clustering coefficient | 0.0000 |
| Avg shortest path length | 1.33 |
| Diameter | 2 |
| Modularity | 0.1950 |
| Number of communities | 2 |
| Avg community size | 2.00 |
| Std community size | 0.00 |
| Min community size | 2 |
| Max community size | 2 |

## PBC Circuit Optimization Summary

| Metric | Value Pre Opt | Value Post Opt | % Reduction |
|---|---|---|---|
| Rotation Operators | N/A | N/A | 0.00% |
| Rotation Layers | N/A | N/A | 0.00% |
| Avg Rotations per Layer | N/A | N/A | 0.00% |
| Measurement Operators | N/A | N/A | 0.00% |
|  |  |  |  |
| Avg Operator Pauli Weight | N/A | N/A | 0.00% |
| Std Operator Pauli Weight | N/A | N/A | 0.00% |
| Max Operator Pauli Weight | N/A | N/A | 0.00% |
|  |  |  |  |
| Avg Qubit Interaction Degree | N/A | N/A | 0.00% |
| Std Qubit Interaction Degree | N/A | N/A | 0.00% |
| Max Qubit Interaction Degree | N/A | N/A | 0.00% |

## Pipeline Timings

| Stage | Time |
|---|---|
| Clifford+T Transpilation | 0.013s |
| PBC Conversion (Total) | 0.000s |


---

