# adder_28q - GS Pipeline Summary
**Parameter:** 3

## General Circuit Info

| Metric | Value |
|---|---|
| Qubits | 28 |
| Total Gates | 463 |
| Depth | 192 |
| Fidelity (vs Original) | N/A |
| Fidelity Method | Skipped |

## Clifford+T Circuit Summary

| Metric | Value |
|---|---|
| Total T-family gates | 168 |
| T gates | 96 |
| Tdg gates | 72 |
| Clifford gates | 295 |
| Two-qubit gates | 195 |
| Circuit depth | 192 |

## Clifford+T Interaction Graph Statistics

| Metric | Value |
|---|---|
| Number of nodes | 28 |
| Number of edges | 39 |
| Graph density | 0.5159 |
| Is connected | True |
| Connected components | 1 |
| Average degree | 2.79 |
| Std dev degree | 0.94 |
| Min degree | 1 |
| Max degree | 4 |
| Clustering coefficient | 0.6310 |
| Avg shortest path length | 5.76 |
| Diameter | 15 |
| Modularity | 0.6564 |
| Number of communities | 3 |
| Avg community size | 9.33 |
| Std community size | 0.47 |
| Min community size | 9 |
| Max community size | 10 |

## PBC Circuit Optimization Summary

| Metric | Value Pre Opt | Value Post Opt | % Reduction |
|---|---|---|---|
| Rotation Operators | N/A | N/A | 0.00% |
| Rotation Layers | N/A | N/A | 0.00% |
| Avg Rotations per Layer | N/A | N/A | 0.00% |
| Measurement Operators | N/A | N/A | 0.00% |
|  |  |  |  |
| Avg Operator Pauli Weight | N/A | N/A | 0.00% |
| Std Operator Pauli Weight | N/A | N/A | 0.00% |
| Max Operator Pauli Weight | N/A | N/A | 0.00% |
|  |  |  |  |
| Avg Qubit Interaction Degree | N/A | N/A | 0.00% |
| Std Qubit Interaction Degree | N/A | N/A | 0.00% |
| Max Qubit Interaction Degree | N/A | N/A | 0.00% |

## Pipeline Timings

| Stage | Time |
|---|---|
| Clifford+T Transpilation | 0.037s |
| PBC Conversion (Total) | 0.000s |


---

# adder_28q - GS Pipeline Summary
**Parameter:** 10

## General Circuit Info

| Metric | Value |
|---|---|
| Qubits | 28 |
| Total Gates | 463 |
| Depth | 192 |
| Fidelity (vs Original) | N/A |
| Fidelity Method | Skipped |

## Clifford+T Circuit Summary

| Metric | Value |
|---|---|
| Total T-family gates | 168 |
| T gates | 96 |
| Tdg gates | 72 |
| Clifford gates | 295 |
| Two-qubit gates | 195 |
| Circuit depth | 192 |

## Clifford+T Interaction Graph Statistics

| Metric | Value |
|---|---|
| Number of nodes | 28 |
| Number of edges | 39 |
| Graph density | 0.5159 |
| Is connected | True |
| Connected components | 1 |
| Average degree | 2.79 |
| Std dev degree | 0.94 |
| Min degree | 1 |
| Max degree | 4 |
| Clustering coefficient | 0.6310 |
| Avg shortest path length | 5.76 |
| Diameter | 15 |
| Modularity | 0.6564 |
| Number of communities | 3 |
| Avg community size | 9.33 |
| Std community size | 0.47 |
| Min community size | 9 |
| Max community size | 10 |

## PBC Circuit Optimization Summary

| Metric | Value Pre Opt | Value Post Opt | % Reduction |
|---|---|---|---|
| Rotation Operators | N/A | N/A | 0.00% |
| Rotation Layers | N/A | N/A | 0.00% |
| Avg Rotations per Layer | N/A | N/A | 0.00% |
| Measurement Operators | N/A | N/A | 0.00% |
|  |  |  |  |
| Avg Operator Pauli Weight | N/A | N/A | 0.00% |
| Std Operator Pauli Weight | N/A | N/A | 0.00% |
| Max Operator Pauli Weight | N/A | N/A | 0.00% |
|  |  |  |  |
| Avg Qubit Interaction Degree | N/A | N/A | 0.00% |
| Std Qubit Interaction Degree | N/A | N/A | 0.00% |
| Max Qubit Interaction Degree | N/A | N/A | 0.00% |

## Pipeline Timings

| Stage | Time |
|---|---|
| Clifford+T Transpilation | 0.019s |
| PBC Conversion (Total) | 0.000s |


---

