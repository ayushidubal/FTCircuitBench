# adder_64q - GS Pipeline Summary
**Parameter:** 3

## General Circuit Info

| Metric | Value |
|---|---|
| Qubits | 64 |
| Total Gates | 1075 |
| Depth | 372 |
| Fidelity (vs Original) | N/A |
| Fidelity Method | Skipped |

## Clifford+T Circuit Summary

| Metric | Value |
|---|---|
| Total T-family gates | 392 |
| T gates | 224 |
| Tdg gates | 168 |
| Clifford gates | 683 |
| Two-qubit gates | 455 |
| Circuit depth | 372 |

## Clifford+T Interaction Graph Statistics

| Metric | Value |
|---|---|
| Number of nodes | 64 |
| Number of edges | 91 |
| Graph density | 0.2257 |
| Is connected | True |
| Connected components | 1 |
| Average degree | 2.84 |
| Std dev degree | 0.91 |
| Min degree | 1 |
| Max degree | 4 |
| Clustering coefficient | 0.6302 |
| Avg shortest path length | 12.46 |
| Diameter | 35 |
| Modularity | 0.8440 |
| Number of communities | 7 |
| Avg community size | 9.14 |
| Std community size | 0.35 |
| Min community size | 9 |
| Max community size | 10 |

## PBC Circuit Optimization Summary

| Metric | Value Pre Opt | Value Post Opt | % Reduction |
|---|---|---|---|
| Rotation Operators | N/A | N/A | 0.00% |
| Rotation Layers | N/A | N/A | 0.00% |
| Avg Rotations per Layer | N/A | N/A | 0.00% |
| Measurement Operators | N/A | N/A | 0.00% |
|  |  |  |  |
| Avg Operator Pauli Weight | N/A | N/A | 0.00% |
| Std Operator Pauli Weight | N/A | N/A | 0.00% |
| Max Operator Pauli Weight | N/A | N/A | 0.00% |
|  |  |  |  |
| Avg Qubit Interaction Degree | N/A | N/A | 0.00% |
| Std Qubit Interaction Degree | N/A | N/A | 0.00% |
| Max Qubit Interaction Degree | N/A | N/A | 0.00% |

## Pipeline Timings

| Stage | Time |
|---|---|
| Clifford+T Transpilation | 0.120s |
| PBC Conversion (Total) | 0.000s |


---

# adder_64q - GS Pipeline Summary
**Parameter:** 10

## General Circuit Info

| Metric | Value |
|---|---|
| Qubits | 64 |
| Total Gates | 1075 |
| Depth | 372 |
| Fidelity (vs Original) | N/A |
| Fidelity Method | Skipped |

## Clifford+T Circuit Summary

| Metric | Value |
|---|---|
| Total T-family gates | 392 |
| T gates | 224 |
| Tdg gates | 168 |
| Clifford gates | 683 |
| Two-qubit gates | 455 |
| Circuit depth | 372 |

## Clifford+T Interaction Graph Statistics

| Metric | Value |
|---|---|
| Number of nodes | 64 |
| Number of edges | 91 |
| Graph density | 0.2257 |
| Is connected | True |
| Connected components | 1 |
| Average degree | 2.84 |
| Std dev degree | 0.91 |
| Min degree | 1 |
| Max degree | 4 |
| Clustering coefficient | 0.6302 |
| Avg shortest path length | 12.46 |
| Diameter | 35 |
| Modularity | 0.8440 |
| Number of communities | 7 |
| Avg community size | 9.14 |
| Std community size | 0.35 |
| Min community size | 9 |
| Max community size | 10 |

## PBC Circuit Optimization Summary

| Metric | Value Pre Opt | Value Post Opt | % Reduction |
|---|---|---|---|
| Rotation Operators | N/A | N/A | 0.00% |
| Rotation Layers | N/A | N/A | 0.00% |
| Avg Rotations per Layer | N/A | N/A | 0.00% |
| Measurement Operators | N/A | N/A | 0.00% |
|  |  |  |  |
| Avg Operator Pauli Weight | N/A | N/A | 0.00% |
| Std Operator Pauli Weight | N/A | N/A | 0.00% |
| Max Operator Pauli Weight | N/A | N/A | 0.00% |
|  |  |  |  |
| Avg Qubit Interaction Degree | N/A | N/A | 0.00% |
| Std Qubit Interaction Degree | N/A | N/A | 0.00% |
| Max Qubit Interaction Degree | N/A | N/A | 0.00% |

## Pipeline Timings

| Stage | Time |
|---|---|
| Clifford+T Transpilation | 0.045s |
| PBC Conversion (Total) | 0.000s |


---

