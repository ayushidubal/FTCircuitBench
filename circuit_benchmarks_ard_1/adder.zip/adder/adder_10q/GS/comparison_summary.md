# adder_10q - GS Pipeline Summary
**Parameter:** 3

## General Circuit Info

| Metric | Value |
|---|---|
| Qubits | 10 |
| Total Gates | 157 |
| Depth | 102 |
| Fidelity (vs Original) | N/A |
| Fidelity Method | Skipped |

## Clifford+T Circuit Summary

| Metric | Value |
|---|---|
| Total T-family gates | 56 |
| T gates | 32 |
| Tdg gates | 24 |
| Clifford gates | 101 |
| Two-qubit gates | 65 |
| Circuit depth | 102 |

## Clifford+T Interaction Graph Statistics

| Metric | Value |
|---|---|
| Number of nodes | 10 |
| Number of edges | 13 |
| Graph density | 1.4444 |
| Is connected | True |
| Connected components | 1 |
| Average degree | 2.60 |
| Std dev degree | 1.02 |
| Min degree | 1 |
| Max degree | 4 |
| Clustering coefficient | 0.6333 |
| Avg shortest path length | 2.33 |
| Diameter | 5 |
| Modularity | 0.3279 |
| Number of communities | 3 |
| Avg community size | 3.33 |
| Std community size | 0.47 |
| Min community size | 3 |
| Max community size | 4 |

## PBC Circuit Optimization Summary

| Metric | Value Pre Opt | Value Post Opt | % Reduction |
|---|---|---|---|
| Rotation Operators | N/A | N/A | 0.00% |
| Rotation Layers | N/A | N/A | 0.00% |
| Avg Rotations per Layer | N/A | N/A | 0.00% |
| Measurement Operators | N/A | N/A | 0.00% |
|  |  |  |  |
| Avg Operator Pauli Weight | N/A | N/A | 0.00% |
| Std Operator Pauli Weight | N/A | N/A | 0.00% |
| Max Operator Pauli Weight | N/A | N/A | 0.00% |
|  |  |  |  |
| Avg Qubit Interaction Degree | N/A | N/A | 0.00% |
| Std Qubit Interaction Degree | N/A | N/A | 0.00% |
| Max Qubit Interaction Degree | N/A | N/A | 0.00% |

## Pipeline Timings

| Stage | Time |
|---|---|
| Clifford+T Transpilation | 0.088s |
| PBC Conversion (Total) | 0.000s |


---

# adder_10q - GS Pipeline Summary
**Parameter:** 10

## General Circuit Info

| Metric | Value |
|---|---|
| Qubits | 10 |
| Total Gates | 157 |
| Depth | 102 |
| Fidelity (vs Original) | N/A |
| Fidelity Method | Skipped |

## Clifford+T Circuit Summary

| Metric | Value |
|---|---|
| Total T-family gates | 56 |
| T gates | 32 |
| Tdg gates | 24 |
| Clifford gates | 101 |
| Two-qubit gates | 65 |
| Circuit depth | 102 |

## Clifford+T Interaction Graph Statistics

| Metric | Value |
|---|---|
| Number of nodes | 10 |
| Number of edges | 13 |
| Graph density | 1.4444 |
| Is connected | True |
| Connected components | 1 |
| Average degree | 2.60 |
| Std dev degree | 1.02 |
| Min degree | 1 |
| Max degree | 4 |
| Clustering coefficient | 0.6333 |
| Avg shortest path length | 2.33 |
| Diameter | 5 |
| Modularity | 0.3279 |
| Number of communities | 3 |
| Avg community size | 3.33 |
| Std community size | 0.47 |
| Min community size | 3 |
| Max community size | 4 |

## PBC Circuit Optimization Summary

| Metric | Value Pre Opt | Value Post Opt | % Reduction |
|---|---|---|---|
| Rotation Operators | N/A | N/A | 0.00% |
| Rotation Layers | N/A | N/A | 0.00% |
| Avg Rotations per Layer | N/A | N/A | 0.00% |
| Measurement Operators | N/A | N/A | 0.00% |
|  |  |  |  |
| Avg Operator Pauli Weight | N/A | N/A | 0.00% |
| Std Operator Pauli Weight | N/A | N/A | 0.00% |
| Max Operator Pauli Weight | N/A | N/A | 0.00% |
|  |  |  |  |
| Avg Qubit Interaction Degree | N/A | N/A | 0.00% |
| Std Qubit Interaction Degree | N/A | N/A | 0.00% |
| Max Qubit Interaction Degree | N/A | N/A | 0.00% |

## Pipeline Timings

| Stage | Time |
|---|---|
| Clifford+T Transpilation | 0.017s |
| PBC Conversion (Total) | 0.000s |


---

