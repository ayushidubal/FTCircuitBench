# qft_29q - GS Pipeline Summary
**Parameter:** 3

## General Circuit Info

| Metric | Value |
|---|---|
| Qubits | 29 |
| Total Gates | 65041 |
| Depth | 9936 |
| Fidelity (vs Original) | N/A |
| Fidelity Method | Skipped |

## Clifford+T Circuit Summary

| Metric | Value |
|---|---|
| Total T-family gates | 24270 |
| T gates | 24242 |
| Tdg gates | 28 |
| Clifford gates | 40771 |
| Two-qubit gates | 812 |
| Circuit depth | 9936 |

## Clifford+T Interaction Graph Statistics

| Metric | Value |
|---|---|
| Number of nodes | 29 |
| Number of edges | 406 |
| Graph density | 2.0000 |
| Is connected | True |
| Connected components | 1 |
| Average degree | 28.00 |
| Std dev degree | 0.00 |
| Min degree | 28 |
| Max degree | 28 |
| Clustering coefficient | 1.0000 |
| Avg shortest path length | 1.00 |
| Diameter | 1 |
| Modularity | 0.0000 |
| Number of communities | 1 |
| Avg community size | 29.00 |
| Std community size | 0.00 |
| Min community size | 29 |
| Max community size | 29 |

## PBC Circuit Optimization Summary

| Metric | Value Pre Opt | Value Post Opt | % Reduction |
|---|---|---|---|
| Rotation Operators | N/A | N/A | 0.00% |
| Rotation Layers | N/A | N/A | 0.00% |
| Avg Rotations per Layer | N/A | N/A | 0.00% |
| Measurement Operators | N/A | N/A | 0.00% |
|  |  |  |  |
| Avg Operator Pauli Weight | N/A | N/A | 0.00% |
| Std Operator Pauli Weight | N/A | N/A | 0.00% |
| Max Operator Pauli Weight | N/A | N/A | 0.00% |
|  |  |  |  |
| Avg Qubit Interaction Degree | N/A | N/A | 0.00% |
| Std Qubit Interaction Degree | N/A | N/A | 0.00% |
| Max Qubit Interaction Degree | N/A | N/A | 0.00% |

## Pipeline Timings

| Stage | Time |
|---|---|
| Clifford+T Transpilation | 0.972s |
| PBC Conversion (Total) | 0.000s |


---

# qft_29q - GS Pipeline Summary
**Parameter:** 10

## General Circuit Info

| Metric | Value |
|---|---|
| Qubits | 29 |
| Total Gates | 197661 |
| Depth | 27933 |
| Fidelity (vs Original) | N/A |
| Fidelity Method | Skipped |

## Clifford+T Circuit Summary

| Metric | Value |
|---|---|
| Total T-family gates | 77380 |
| T gates | 77352 |
| Tdg gates | 28 |
| Clifford gates | 120281 |
| Two-qubit gates | 812 |
| Circuit depth | 27933 |

## Clifford+T Interaction Graph Statistics

| Metric | Value |
|---|---|
| Number of nodes | 29 |
| Number of edges | 406 |
| Graph density | 2.0000 |
| Is connected | True |
| Connected components | 1 |
| Average degree | 28.00 |
| Std dev degree | 0.00 |
| Min degree | 28 |
| Max degree | 28 |
| Clustering coefficient | 1.0000 |
| Avg shortest path length | 1.00 |
| Diameter | 1 |
| Modularity | 0.0000 |
| Number of communities | 1 |
| Avg community size | 29.00 |
| Std community size | 0.00 |
| Min community size | 29 |
| Max community size | 29 |

## PBC Circuit Optimization Summary

| Metric | Value Pre Opt | Value Post Opt | % Reduction |
|---|---|---|---|
| Rotation Operators | N/A | N/A | 0.00% |
| Rotation Layers | N/A | N/A | 0.00% |
| Avg Rotations per Layer | N/A | N/A | 0.00% |
| Measurement Operators | N/A | N/A | 0.00% |
|  |  |  |  |
| Avg Operator Pauli Weight | N/A | N/A | 0.00% |
| Std Operator Pauli Weight | N/A | N/A | 0.00% |
| Max Operator Pauli Weight | N/A | N/A | 0.00% |
|  |  |  |  |
| Avg Qubit Interaction Degree | N/A | N/A | 0.00% |
| Std Qubit Interaction Degree | N/A | N/A | 0.00% |
| Max Qubit Interaction Degree | N/A | N/A | 0.00% |

## Pipeline Timings

| Stage | Time |
|---|---|
| Clifford+T Transpilation | 2.09s |
| PBC Conversion (Total) | 0.000s |


---

