# qft_4q - GS Pipeline Summary
**Parameter:** 3

## General Circuit Info

| Metric | Value |
|---|---|
| Qubits | 4 |
| Total Gates | 728 |
| Depth | 575 |
| Fidelity (vs Original) | N/A |
| Fidelity Method | Skipped |

## Clifford+T Circuit Summary

| Metric | Value |
|---|---|
| Total T-family gates | 267 |
| T gates | 264 |
| Tdg gates | 3 |
| Clifford gates | 461 |
| Two-qubit gates | 12 |
| Circuit depth | 575 |

## Clifford+T Interaction Graph Statistics

| Metric | Value |
|---|---|
| Number of nodes | 4 |
| Number of edges | 6 |
| Graph density | 2.0000 |
| Is connected | True |
| Connected components | 1 |
| Average degree | 3.00 |
| Std dev degree | 0.00 |
| Min degree | 3 |
| Max degree | 3 |
| Clustering coefficient | 1.0000 |
| Avg shortest path length | 1.00 |
| Diameter | 1 |
| Modularity | 0.0000 |
| Number of communities | 1 |
| Avg community size | 4.00 |
| Std community size | 0.00 |
| Min community size | 4 |
| Max community size | 4 |

## PBC Circuit Optimization Summary

| Metric | Value Pre Opt | Value Post Opt | % Reduction |
|---|---|---|---|
| Rotation Operators | N/A | N/A | 0.00% |
| Rotation Layers | N/A | N/A | 0.00% |
| Avg Rotations per Layer | N/A | N/A | 0.00% |
| Measurement Operators | N/A | N/A | 0.00% |
|  |  |  |  |
| Avg Operator Pauli Weight | N/A | N/A | 0.00% |
| Std Operator Pauli Weight | N/A | N/A | 0.00% |
| Max Operator Pauli Weight | N/A | N/A | 0.00% |
|  |  |  |  |
| Avg Qubit Interaction Degree | N/A | N/A | 0.00% |
| Std Qubit Interaction Degree | N/A | N/A | 0.00% |
| Max Qubit Interaction Degree | N/A | N/A | 0.00% |

## Pipeline Timings

| Stage | Time |
|---|---|
| Clifford+T Transpilation | 0.042s |
| PBC Conversion (Total) | 0.000s |


---

# qft_4q - GS Pipeline Summary
**Parameter:** 10

## General Circuit Info

| Metric | Value |
|---|---|
| Qubits | 4 |
| Total Gates | 2377 |
| Depth | 1838 |
| Fidelity (vs Original) | N/A |
| Fidelity Method | Skipped |

## Clifford+T Circuit Summary

| Metric | Value |
|---|---|
| Total T-family gates | 903 |
| T gates | 900 |
| Tdg gates | 3 |
| Clifford gates | 1474 |
| Two-qubit gates | 12 |
| Circuit depth | 1838 |

## Clifford+T Interaction Graph Statistics

| Metric | Value |
|---|---|
| Number of nodes | 4 |
| Number of edges | 6 |
| Graph density | 2.0000 |
| Is connected | True |
| Connected components | 1 |
| Average degree | 3.00 |
| Std dev degree | 0.00 |
| Min degree | 3 |
| Max degree | 3 |
| Clustering coefficient | 1.0000 |
| Avg shortest path length | 1.00 |
| Diameter | 1 |
| Modularity | 0.0000 |
| Number of communities | 1 |
| Avg community size | 4.00 |
| Std community size | 0.00 |
| Min community size | 4 |
| Max community size | 4 |

## PBC Circuit Optimization Summary

| Metric | Value Pre Opt | Value Post Opt | % Reduction |
|---|---|---|---|
| Rotation Operators | N/A | N/A | 0.00% |
| Rotation Layers | N/A | N/A | 0.00% |
| Avg Rotations per Layer | N/A | N/A | 0.00% |
| Measurement Operators | N/A | N/A | 0.00% |
|  |  |  |  |
| Avg Operator Pauli Weight | N/A | N/A | 0.00% |
| Std Operator Pauli Weight | N/A | N/A | 0.00% |
| Max Operator Pauli Weight | N/A | N/A | 0.00% |
|  |  |  |  |
| Avg Qubit Interaction Degree | N/A | N/A | 0.00% |
| Std Qubit Interaction Degree | N/A | N/A | 0.00% |
| Max Qubit Interaction Degree | N/A | N/A | 0.00% |

## Pipeline Timings

| Stage | Time |
|---|---|
| Clifford+T Transpilation | 0.068s |
| PBC Conversion (Total) | 0.000s |


---

