# qft_18q - GS Pipeline Summary
**Parameter:** 3

## General Circuit Info

| Metric | Value |
|---|---|
| Qubits | 18 |
| Total Gates | 31467 |
| Depth | 5590 |
| Fidelity (vs Original) | N/A |
| Fidelity Method | Skipped |

## Clifford+T Circuit Summary

| Metric | Value |
|---|---|
| Total T-family gates | 11631 |
| T gates | 11614 |
| Tdg gates | 17 |
| Clifford gates | 19836 |
| Two-qubit gates | 306 |
| Circuit depth | 5590 |

## Clifford+T Interaction Graph Statistics

| Metric | Value |
|---|---|
| Number of nodes | 18 |
| Number of edges | 153 |
| Graph density | 2.0000 |
| Is connected | True |
| Connected components | 1 |
| Average degree | 17.00 |
| Std dev degree | 0.00 |
| Min degree | 17 |
| Max degree | 17 |
| Clustering coefficient | 1.0000 |
| Avg shortest path length | 1.00 |
| Diameter | 1 |
| Modularity | 0.0000 |
| Number of communities | 1 |
| Avg community size | 18.00 |
| Std community size | 0.00 |
| Min community size | 18 |
| Max community size | 18 |

## PBC Circuit Optimization Summary

| Metric | Value Pre Opt | Value Post Opt | % Reduction |
|---|---|---|---|
| Rotation Operators | N/A | N/A | 0.00% |
| Rotation Layers | N/A | N/A | 0.00% |
| Avg Rotations per Layer | N/A | N/A | 0.00% |
| Measurement Operators | N/A | N/A | 0.00% |
|  |  |  |  |
| Avg Operator Pauli Weight | N/A | N/A | 0.00% |
| Std Operator Pauli Weight | N/A | N/A | 0.00% |
| Max Operator Pauli Weight | N/A | N/A | 0.00% |
|  |  |  |  |
| Avg Qubit Interaction Degree | N/A | N/A | 0.00% |
| Std Qubit Interaction Degree | N/A | N/A | 0.00% |
| Max Qubit Interaction Degree | N/A | N/A | 0.00% |

## Pipeline Timings

| Stage | Time |
|---|---|
| Clifford+T Transpilation | 0.782s |
| PBC Conversion (Total) | 0.000s |


---

# qft_18q - GS Pipeline Summary
**Parameter:** 10

## General Circuit Info

| Metric | Value |
|---|---|
| Qubits | 18 |
| Total Gates | 95535 |
| Depth | 16097 |
| Fidelity (vs Original) | N/A |
| Fidelity Method | Skipped |

## Clifford+T Circuit Summary

| Metric | Value |
|---|---|
| Total T-family gates | 37725 |
| T gates | 37708 |
| Tdg gates | 17 |
| Clifford gates | 57810 |
| Two-qubit gates | 306 |
| Circuit depth | 16097 |

## Clifford+T Interaction Graph Statistics

| Metric | Value |
|---|---|
| Number of nodes | 18 |
| Number of edges | 153 |
| Graph density | 2.0000 |
| Is connected | True |
| Connected components | 1 |
| Average degree | 17.00 |
| Std dev degree | 0.00 |
| Min degree | 17 |
| Max degree | 17 |
| Clustering coefficient | 1.0000 |
| Avg shortest path length | 1.00 |
| Diameter | 1 |
| Modularity | 0.0000 |
| Number of communities | 1 |
| Avg community size | 18.00 |
| Std community size | 0.00 |
| Min community size | 18 |
| Max community size | 18 |

## PBC Circuit Optimization Summary

| Metric | Value Pre Opt | Value Post Opt | % Reduction |
|---|---|---|---|
| Rotation Operators | N/A | N/A | 0.00% |
| Rotation Layers | N/A | N/A | 0.00% |
| Avg Rotations per Layer | N/A | N/A | 0.00% |
| Measurement Operators | N/A | N/A | 0.00% |
|  |  |  |  |
| Avg Operator Pauli Weight | N/A | N/A | 0.00% |
| Std Operator Pauli Weight | N/A | N/A | 0.00% |
| Max Operator Pauli Weight | N/A | N/A | 0.00% |
|  |  |  |  |
| Avg Qubit Interaction Degree | N/A | N/A | 0.00% |
| Std Qubit Interaction Degree | N/A | N/A | 0.00% |
| Max Qubit Interaction Degree | N/A | N/A | 0.00% |

## Pipeline Timings

| Stage | Time |
|---|---|
| Clifford+T Transpilation | 0.665s |
| PBC Conversion (Total) | 0.000s |


---

