# qft_63q - GS Pipeline Summary
**Parameter:** 3

## General Circuit Info

| Metric | Value |
|---|---|
| Qubits | 63 |
| Total Gates | 173629 |
| Depth | 23530 |
| Fidelity (vs Original) | N/A |
| Fidelity Method | Skipped |

## Clifford+T Circuit Summary

| Metric | Value |
|---|---|
| Total T-family gates | 63336 |
| T gates | 63274 |
| Tdg gates | 62 |
| Clifford gates | 110293 |
| Two-qubit gates | 3906 |
| Circuit depth | 23530 |

## Clifford+T Interaction Graph Statistics

| Metric | Value |
|---|---|
| Number of nodes | 63 |
| Number of edges | 1953 |
| Graph density | 2.0000 |
| Is connected | True |
| Connected components | 1 |
| Average degree | 62.00 |
| Std dev degree | 0.00 |
| Min degree | 62 |
| Max degree | 62 |
| Clustering coefficient | 1.0000 |
| Avg shortest path length | 1.00 |
| Diameter | 1 |
| Modularity | 0.0000 |
| Number of communities | 1 |
| Avg community size | 63.00 |
| Std community size | 0.00 |
| Min community size | 63 |
| Max community size | 63 |

## PBC Circuit Optimization Summary

| Metric | Value Pre Opt | Value Post Opt | % Reduction |
|---|---|---|---|
| Rotation Operators | N/A | N/A | 0.00% |
| Rotation Layers | N/A | N/A | 0.00% |
| Avg Rotations per Layer | N/A | N/A | 0.00% |
| Measurement Operators | N/A | N/A | 0.00% |
|  |  |  |  |
| Avg Operator Pauli Weight | N/A | N/A | 0.00% |
| Std Operator Pauli Weight | N/A | N/A | 0.00% |
| Max Operator Pauli Weight | N/A | N/A | 0.00% |
|  |  |  |  |
| Avg Qubit Interaction Degree | N/A | N/A | 0.00% |
| Std Qubit Interaction Degree | N/A | N/A | 0.00% |
| Max Qubit Interaction Degree | N/A | N/A | 0.00% |

## Pipeline Timings

| Stage | Time |
|---|---|
| Clifford+T Transpilation | 2.86s |
| PBC Conversion (Total) | 0.000s |


---

# qft_63q - GS Pipeline Summary
**Parameter:** 10

## General Circuit Info

| Metric | Value |
|---|---|
| Qubits | 63 |
| Total Gates | 511147 |
| Depth | 63424 |
| Fidelity (vs Original) | N/A |
| Fidelity Method | Skipped |

## Clifford+T Circuit Summary

| Metric | Value |
|---|---|
| Total T-family gates | 199950 |
| T gates | 199888 |
| Tdg gates | 62 |
| Clifford gates | 311197 |
| Two-qubit gates | 3906 |
| Circuit depth | 63424 |

## Clifford+T Interaction Graph Statistics

| Metric | Value |
|---|---|
| Number of nodes | 63 |
| Number of edges | 1953 |
| Graph density | 2.0000 |
| Is connected | True |
| Connected components | 1 |
| Average degree | 62.00 |
| Std dev degree | 0.00 |
| Min degree | 62 |
| Max degree | 62 |
| Clustering coefficient | 1.0000 |
| Avg shortest path length | 1.00 |
| Diameter | 1 |
| Modularity | 0.0000 |
| Number of communities | 1 |
| Avg community size | 63.00 |
| Std community size | 0.00 |
| Min community size | 63 |
| Max community size | 63 |

## PBC Circuit Optimization Summary

| Metric | Value Pre Opt | Value Post Opt | % Reduction |
|---|---|---|---|
| Rotation Operators | N/A | N/A | 0.00% |
| Rotation Layers | N/A | N/A | 0.00% |
| Avg Rotations per Layer | N/A | N/A | 0.00% |
| Measurement Operators | N/A | N/A | 0.00% |
|  |  |  |  |
| Avg Operator Pauli Weight | N/A | N/A | 0.00% |
| Std Operator Pauli Weight | N/A | N/A | 0.00% |
| Max Operator Pauli Weight | N/A | N/A | 0.00% |
|  |  |  |  |
| Avg Qubit Interaction Degree | N/A | N/A | 0.00% |
| Std Qubit Interaction Degree | N/A | N/A | 0.00% |
| Max Qubit Interaction Degree | N/A | N/A | 0.00% |

## Pipeline Timings

| Stage | Time |
|---|---|
| Clifford+T Transpilation | 5.77s |
| PBC Conversion (Total) | 0.000s |


---

